﻿namespace ProjectInterview.Models
{
    public class DataEntry
    {
        public string Date { get; set; }
        public decimal MarketPrice { get; set; }
    }
}
